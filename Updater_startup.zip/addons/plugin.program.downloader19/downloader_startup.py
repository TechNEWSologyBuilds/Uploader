﻿import os, xbmc, xbmcgui, xbmcvfs
from updatervar import *
#from resources.lib.modules.delete_addons import del_dir
from resources.lib.modules.installer_addons import installAddon

Dialog_U1 = "[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]"
Dialog_U2 = "Περιμένετε χωρίς να πατήσετε κάτι..."
Dialog_U3 = "Εισαγωγή στοιχείων..."
Dialog_U4 = "[B]Ολοκληρώθηκε με επιτυχία[/B]"
Dialog_U5 = "To Build είναι ενημερωμένο!"
Dialog_U6 = "Έλεγχος..."

def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U3)
    xbmc.sleep(500)
    BG.update(5, Dialog_U1, Dialog_U6)
#    del_dir()                                     ### delete addons ands files ###
    installAddon()
    xbmc.sleep(500)
    BG.update(25, Dialog_U1, Dialog_U2)

    xbmc.sleep(1000)
    BG.update(30, Dialog_U1, Dialog_U2)
    if not os.path.exists(UpdaterMatrix_path):
        xbmc.executebuiltin(UpdaterMatrix_1)
        xbmc.sleep(1000)
        
    BG.update(33, Dialog_U1, Dialog_U2)

    if not os.path.exists(UpdaterMatrix_path2):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_2)
    BG.update(36, Dialog_U1, Dialog_U2)

    xbmcvfs.delete(UpdaterMatrix_path3)
    xbmc.sleep(1000)
    xbmcvfs.delete(UpdaterMatrix_path4)

    BG.update(40, Dialog_U1, Dialog_U2)

    if not os.path.exists(UpdaterMatrix_path6):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_6)
        xbmc.sleep(6000)
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')

    BG.update(50, Dialog_U1, Dialog_U2)

    if not os.path.exists(UpdaterMatrix_path5):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_5)
        xbmc.sleep(2000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.sleep(5000)
        xbmc.executebuiltin("ReloadSkin()")

    BG.update(100, Dialog_U4, Dialog_U5)
    installAddon()
    BG.update(100, Dialog_U4, Dialog_U5)

    BG.close()
    xbmcvfs.delete(downloader_startup_delete)

Updater_Matrix()
