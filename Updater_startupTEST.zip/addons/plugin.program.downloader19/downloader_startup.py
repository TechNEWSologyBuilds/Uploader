﻿import os, xbmc, xbmcgui, xbmcvfs
from updatervar import *
#from resources.lib.modules.delete_addons import del_dir
from resources.lib.modules.installer_addons import installAddon



def Updater_Matrix():
#    del_dir()                                     ### delete addons ands files ###
    installAddon()

    if not os.path.exists(UpdaterMatrix_path):
        xbmc.executebuiltin(UpdaterMatrix_1)
        xbmc.sleep(1000)

    if not os.path.exists(UpdaterMatrix_path2):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_2)

    if not os.path.exists(UpdaterMatrix_path3):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_3)

    if not os.path.exists(UpdaterMatrix_path4):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_4)

    if not os.path.exists(UpdaterMatrix_path5):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_5)

    if not os.path.exists(UpdaterMatrix_path6):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_6)

    xbmcvfs.delete(downloader_startup_delete)

Updater_Matrix()
